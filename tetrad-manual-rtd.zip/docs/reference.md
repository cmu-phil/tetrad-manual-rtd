
# Reference

## Parameter Definitions

These are maintained as a flat, machine-readable text and consumed by the UI.  
For now we ship the verbatim file as a static asset:

- [`parameter.definitions.txt`](./_static/manual/parameter.definitions.txt)

> Later, we can generate a Markdown table from this file at build time.
