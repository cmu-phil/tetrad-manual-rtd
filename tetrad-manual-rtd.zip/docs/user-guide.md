
# User Guide

The classic manual content (HTML) is embedded here as a static asset.  
Open the full manual shell (without parameter definitions) below:

- **Manual (cleaned)**: [`index.cleaned2.html`](./_static/manual/index.cleaned2.html)

> Tip: Over time, consider migrating sections into native Markdown pages to benefit from
> Read the Docs search, cross-references, and versioning.
