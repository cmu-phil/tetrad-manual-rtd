
# What’s New

Open the bundled "What’s New" page:

- [`whats-new.html`](./_static/manual/whats-new.html)
