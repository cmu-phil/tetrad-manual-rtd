
# Search Algorithms

There are two complementary algorithm pages:

- **Curated, user-friendly guide**: [`search-algorithms.html`](./_static/manual/search-algorithms.html)
- **Complete legacy extract**: [`search-algorithms.full.html`](./_static/manual/search-algorithms.full.html)

If you add new algorithms, you can also host an **Additions** page alongside these.
